package com.lagou.demo.controller;

import com.lagou.edu.mvcframework.annotations.LagouController;
import com.lagou.edu.mvcframework.annotations.LagouRequestMapping;
import com.lagou.edu.mvcframework.annotations.Security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author liuxingzhu
 * @date 2020-04-12 12:52
 */
@LagouController
@Security({"lisi,wangwu"})
@LagouRequestMapping("/demo")
public class StudyController {

    /**
     * URL: /demo/study?name=lisi
     * @param request
     * @param response
     * @param name
     * @return
     */
    @LagouRequestMapping("/study")
    @Security({"lisi"})
    public String study(HttpServletRequest request, HttpServletResponse response, String name) {
        return "success";
    }

    /**
     * URL: /demo/study?name=lisi
     * @param request
     * @param response
     * @param name
     * @return
     */
    @LagouRequestMapping("/exercise")
    public String exercise(HttpServletRequest request, HttpServletResponse response, String name) {
        return "success";
    }
}
