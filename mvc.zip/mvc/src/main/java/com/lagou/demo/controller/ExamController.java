package com.lagou.demo.controller;

import com.lagou.edu.mvcframework.annotations.LagouController;
import com.lagou.edu.mvcframework.annotations.LagouRequestMapping;
import com.lagou.edu.mvcframework.annotations.Security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author liuxingzhu
 * @date 2020-04-12 12:52
 */
@LagouController
@LagouRequestMapping("/demo")
public class ExamController {

    /**
     * URL: /demo/exam?name=zhangsan
     * @param request
     * @param response
     * @param name
     * @return
     */
    @LagouRequestMapping("/exam")
    @Security({"zhangsan"})
    public String exam(HttpServletRequest request, HttpServletResponse response, String name) {
        return "success";
    }
}
